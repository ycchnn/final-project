# Introduction to Programming II Final Project Template
> Class Hwann-Tzong Chen

## Resource

- Allegro download: [https ://github.com/liballeg/allegro5/releases](https://github.com/liballeg/allegro5/releases)
- Allegro install(Mac OS): [https://hackmd.io/@Jiza/BkZ5a5yL2](https://hackmd.io/@Jiza/BkZ5a5yL2)
- Allegro documentation: [https://www.allegro.cc/manual/5/index.html](https://www.allegro.cc/manual/5/index.html)
- GIF convert: [https://ezgif.com/video-to-gif](https://ezgif.com/video-to-gif)
